package com.caps.project.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.caps.project.dao.Dao;
import com.caps.project.dto.HotelDTO;

@Service
public class HotelService {
	
	@Autowired
	private Dao dao;
	
	public  boolean addHotel(HotelDTO hotelDTO) {
		 boolean status=dao.addHotel(hotelDTO);
		    return status;
		
	}

	public boolean updateHotel(HotelDTO dto) {
		boolean status=dao.updateHotel(dto);
	    return status;
	}

	public boolean deleteHotel(int primarykey) {
		boolean status=dao.deleteHotel(primarykey);
	    return status;
	}

	public HotelDTO searchHotel(int id) {
		
		HotelDTO hotelDTO=dao.searchHotel(id);
	    return hotelDTO;
	}

}
