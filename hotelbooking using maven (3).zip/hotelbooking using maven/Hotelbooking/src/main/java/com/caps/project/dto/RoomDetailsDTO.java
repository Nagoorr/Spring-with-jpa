package com.caps.project.dto;


import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

@Entity
@Table(name="roomdetails")
public class RoomDetailsDTO implements Serializable{
    
	 @Column(name="hotel_id")
	private int hotelId;
	 @Id @Column(name="room_id")
	 @GeneratedValue(strategy=GenerationType.AUTO)
	private int roomId;
	 @Column(name="room_no")
	private int roomNo;
	 @Column(name="room_type")
	private String roomType;
	 @Column(name="per_night_rate")
	private double perNightRate;
	 @Column(name="availability")
	private boolean availability;
	public int getHotelId() {
		return hotelId;
	}
	public void setHotelId(int hotelId) {
		this.hotelId = hotelId;
	}
	public int getRoomId() {
		return roomId;
	}
	public void setRoomId(int roomId) {
		this.roomId = roomId;
	}
	public int getRoomNo() {
		return roomNo;
	}
	public void setRoomNo(int roomNo) {
		this.roomNo = roomNo;
	}
	public String getRoomType() {
		return roomType;
	}
	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}
	public double getPerNightRate() {
		return perNightRate;
	}
	public void setPerNightRate(double perNightRate) {
		this.perNightRate = perNightRate;
	}
	public boolean isAvailability() {
		return availability;
	}
	public void setAvailability(boolean availability) {
		this.availability = availability;
	}

	@Override
	public String toString() {
		return "RoomDetailsDTO [hotelId=" + hotelId + ", roomId=" + roomId + ", roomNo=" + roomNo + ", roomType="
				+ roomType + ", perNightRate=" + perNightRate + ", availability=" + availability + 
				"]";

}
}
