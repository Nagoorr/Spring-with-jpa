package com.caps.project.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.caps.project.dto.HotelDTO;
import com.caps.project.service.HotelService;

@Controller
@RequestMapping("/user")
public class HotelController {
	
	@Autowired
	private HotelService hotelService;
	
	@RequestMapping(value = "/addhotelpage",method = RequestMethod.GET)
	public String addHotel()
	{
		return "AddHotel";
	}
	
	@RequestMapping(value = "/updatehotelpage",method = RequestMethod.GET)
	public String updateHotel()
	{
		return "UpdateHotel";
	}

	@RequestMapping(value = "/deletehotelpage",method = RequestMethod.GET)
	public String daleteHotel()
	{
		return "DeleteHotel";
	}
	
	@RequestMapping(value = "/searchhotelpage",method = RequestMethod.GET)
	public String searchHotel()
	{
		return "SearchHotel";
	}
	
	@RequestMapping(value="/addhotel",method=RequestMethod.POST)
	public ModelAndView  addHotel(@ModelAttribute HotelDTO hotelDTO) {


		boolean result=hotelService.addHotel(hotelDTO);

		if(result)
		{
			return new ModelAndView("AdminHomePage");
		}
		else
		{
			return new ModelAndView("RegisterHotel");
		}

	}
	
	@RequestMapping(value="/updatehotel",method=RequestMethod.POST)
	public ModelAndView  updateHotel(@ModelAttribute HotelDTO hotelDTO ) {


		boolean result=hotelService.updateHotel(hotelDTO);

		if(result)
		{
			return new ModelAndView("AdminHomePage");
		}
		else
		{
			return new ModelAndView("UpdateHotel");
		}

	}
	
	@RequestMapping(value="/deletehotel",method=RequestMethod.POST)
	public ModelAndView  deleteHotel(@RequestParam("hotelId") int primarykey) {


		boolean result=hotelService.deleteHotel(primarykey);

		if(result)
		{
			return new ModelAndView("AdminHomePage");
		}
		else
		{
			return new ModelAndView("DeleteHotel");
		}

	}
	
	@RequestMapping(value="/searchhotel",method=RequestMethod.GET)
	public ModelAndView  searchHotel(@RequestParam("hotelId") int id) {


		HotelDTO hotelDTO2=hotelService.searchHotel(id);

		if(hotelDTO2!=null)
		{
			
			return new ModelAndView("HotelDetails","details", hotelDTO2);
		}
		else
		{
			return new ModelAndView("SearchHotel");
		}

	}
	

}
