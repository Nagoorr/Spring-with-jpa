package com.caps.project.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceUnit;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.swing.text.html.parser.DTD;

import org.springframework.stereotype.Repository;
import org.springframework.web.multipart.MultipartFile;

import com.caps.project.dto.BookingDetailsDTO;
import com.caps.project.dto.HotelDTO;
import com.caps.project.dto.RoomDetailsDTO;
import com.caps.project.dto.UserDTO;
import com.caps.project.util.JpaUtil;

@Repository
public class DaoImpl implements Dao{



	EntityManagerFactory entityManagerFactory=JpaUtil.getEntityManagerFactory();

	public boolean registerUser(UserDTO userDTO) {
		boolean status=false;

		EntityManager entityManager =entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		try
		{
			entityManager.persist(userDTO);
			entityManager.getTransaction().commit();
			status= true;
		}catch (Exception e) {
			e.printStackTrace();
			entityManager.getTransaction().rollback();
		}

		entityManager.close();
		return status;
	}

	public boolean updateUser(UserDTO userDTO) {
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();

		try {

			String hql="update UserDTO user set user.password=:pass,user.mobileNo=:mno,user.phone=:ph,user.email=:em,user.address=:add where "
					+ "user.userName=:uname and user.role=:role";

			Query query=entityManager.createQuery(hql);
			query.setParameter("pass", userDTO.getPassword());
			query.setParameter("mno", userDTO.getMobileNo());
			query.setParameter("ph", userDTO.getPhone());
			query.setParameter("em", userDTO.getEmail());
			query.setParameter("add", userDTO.getAddress());
			query.setParameter("uname", userDTO.getUserName());
			query.setParameter("role", userDTO.getRole());

			int count=query.executeUpdate();

			if(count>0)
			{

				entityManager.getTransaction().commit();
				return true;
			}
			else
			{
				return false;
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			entityManager.getTransaction().rollback();
		}

		entityManager.close();

		return false;

	}


	public boolean deleteUser(String name,String password) {

		boolean status=false;
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction();
		transaction.begin();
		String hql="Delete from UserDTO us where us.userName=:name and us.password=:pass";
		Query query=entityManager.createQuery(hql);

		query.setParameter("name",name );
		query.setParameter("pass", password);

		try {
			int count = query.executeUpdate();
			if(count>0)
			{
				status=true;
			}

		}
		catch (Exception e) {
			e.printStackTrace();
			transaction.rollback();
		}
		finally {

			entityManager.close();
		}

		return status;


	}

	public UserDTO userLogin(UserDTO userdto) {
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction();
		transaction.begin();
		String hql="from UserDTO us where us.userName=:name and us.password=:pass";
		Query query=entityManager.createQuery(hql);

		query.setParameter("name",userdto.getUserName() );
		query.setParameter("pass", userdto.getPassword());


		List  allUsers=null;
		UserDTO dto=null;
		try {
			allUsers = query.getResultList();
			for (Object object : allUsers) {
				dto=(UserDTO)object;
				return dto;
			}

		}
		catch (Exception e) {
			e.printStackTrace();
			transaction.rollback();
		}
		entityManager.close();
		return dto;

	}

	public HotelDTO searchHotel(int id) {

		EntityManager entityManager=entityManagerFactory.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction();
		transaction.begin();
		HotelDTO hotelDTO=null;
		try {
			hotelDTO=entityManager.find(HotelDTO.class,id );
			return hotelDTO;
		}
		catch (Exception e) {
			e.printStackTrace();
			transaction.rollback();
		}
		entityManager.close();

		return hotelDTO;

	}

	public boolean booking(BookingDetailsDTO bookingDetailsDTO) {
		boolean status=false;
		EntityManager entityManager =entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		try
		{
			entityManager.persist(bookingDetailsDTO);

			entityManager.getTransaction().commit();
			status= true;
		}catch (Exception e) {
			e.printStackTrace();
			entityManager.getTransaction().rollback();
		}

		entityManager.close();
		return status;
	}

	public boolean addHotel(HotelDTO hotelDTO) {
		boolean status=false;
		EntityManager entityManager =entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		try
		{
			entityManager.persist(hotelDTO);

			entityManager.getTransaction().commit();
			status= true;
		}catch (Exception e) {
			e.printStackTrace();
			entityManager.getTransaction().rollback();
		}

		entityManager.close();
		return status;
	}

	public boolean updateHotel(HotelDTO hotelDTO) {
		boolean status=false;
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		try {
			String hql="update HotelDTO hotel set hotel.hotelName=:name,hotel.city=:city,hotel.address=:add,hotel.description=:desc,"
					+ "hotel.averageRatePernight=:avg,hotel.phoneNo1=:pn1,hotel.phoneNo2=:pn2,hotel.fax=:fax,hotel.email=:em,hotel.rating=:rat where hotel.hotelId=:hId";

			Query query=entityManager.createQuery(hql);
			query.setParameter("name", hotelDTO.getHotelName());
			query.setParameter("city", hotelDTO.getCity());
			query.setParameter("add", hotelDTO.getAddress());
			query.setParameter("desc", hotelDTO.getDescription());
			query.setParameter("avg", hotelDTO.getAverageRatePernight());
			query.setParameter("pn1", hotelDTO.getPhoneNo1());
			query.setParameter("pn2", hotelDTO.getPhoneNo2());
			query.setParameter("fax", hotelDTO.getFax());
			query.setParameter("em", hotelDTO.getEmail());
			query.setParameter("rat", hotelDTO.getRating());
			query.setParameter("hId", hotelDTO.getHotelId());

			int count=query.executeUpdate();

			if(count>0)
			{
				status=true;
			}
			else
			{
				status=false;
			}


		}
		catch (Exception e) {
			e.printStackTrace();
			entityManager.getTransaction().rollback();
		}

		entityManager.close();

		return status;
	}

	public boolean deleteHotel(int id) {
		boolean status=false;
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction();
		transaction.begin();
		try {
			String hql="Delete from HotelDTO hd where hd.hotelId=:id ";
			Query query=entityManager.createQuery(hql);

			query.setParameter("id",id );

			int count=query.executeUpdate();
			if(count>0)
			{
				return status=true;
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			transaction.rollback();
		}
		entityManager.close();

		return status;
	}

	public boolean addRoom(RoomDetailsDTO roomDetailsDTO) {
		boolean status=false;
		EntityManager entityManager =entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		try
		{

			entityManager.persist(roomDetailsDTO);

			entityManager.getTransaction().commit();
			status= true;

		}catch (Exception e) {
			e.printStackTrace();
			entityManager.getTransaction().rollback();
		}

		entityManager.close();
		return status;
	}

	public boolean updateRoom(RoomDetailsDTO detailsDTO) {
		boolean status=false;
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		try {
			String hql="update RoomDetailsDTO  room set room.hotelId=:hid,room.roomNo=:rno,room.roomType=:rtype,room.availability=:av "
					+ " where room.roomId=:rid";

			Query query=entityManager.createQuery(hql);
			query.setParameter("hid", detailsDTO.getHotelId());
			query.setParameter("rno", detailsDTO.getRoomNo());
			query.setParameter("rtype", detailsDTO.getRoomType());
			query.setParameter("av", detailsDTO.isAvailability());
			query.setParameter("rid", detailsDTO.getRoomId());

			int count=query.executeUpdate();

			if(count>0)
			{

				entityManager.getTransaction().commit();
				return status=true;
			}
			else
			{
				return status=false;
			}

		}
		catch (Exception e) {
			e.printStackTrace();
			entityManager.getTransaction().rollback();
		}

		entityManager.close();

		return status;
	}

	public RoomDetailsDTO searchRoom(int id) {
		EntityManagerFactory entityManagerFactory=JpaUtil.getEntityManagerFactory();
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction();
		transaction.begin();
		RoomDetailsDTO roomDetailsDTO=null;
		try {
			roomDetailsDTO=entityManager.find(RoomDetailsDTO.class,id );
			return roomDetailsDTO;
		}
		catch (Exception e) {
			e.printStackTrace();
			transaction.rollback();
		}
		entityManager.close();

		return roomDetailsDTO;
	}

	public boolean deleteRoom(int id) {
		boolean status=false;
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction();
		transaction.begin();
		try {
			String hql="Delete from RoomDetailsDTO room where room.roomId=:id ";
			Query query=entityManager.createQuery(hql);

			query.setParameter("id",id );

			int count=query.executeUpdate();
			if(count>0)
			{
				return status=true;
			}
			status=true;
		}
		catch (Exception e) {
			e.printStackTrace();
			transaction.rollback();
		}
		entityManager.close();

		return status;
	}


	public List<UserDTO> listUsers() {

		List<UserDTO> userList=new ArrayList<UserDTO>();
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction();
		transaction.begin();
		UserDTO usersList=new UserDTO();
		try {
			String hql="SELECT users FROM UserDTO users";
			Query query=entityManager.createQuery(hql);
			userList = query.getResultList();
			 userList.add(usersList);
			transaction.commit();
		}
		catch (Exception e) {
			e.printStackTrace();
			transaction.rollback();
		}
		entityManager.close();

		return userList;

	}

	public List<HotelDTO> listHotels() {
		List<HotelDTO> hotelsList=null;
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction();
		transaction.begin();
		String hql="SELECT hotels FROM HotelDTO hotels";
		Query query=entityManager.createQuery(hql);

		try {
			hotelsList = query.getResultList();
			transaction.commit();
			return hotelsList;
		}
		catch (Exception e) {
			e.printStackTrace();
			transaction.rollback();
		}
		entityManager.close();

		return hotelsList;
	}

	public List<RoomDetailsDTO> listRooms() {
		List<RoomDetailsDTO> roomDetailsDTOs=null;
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction();
		transaction.begin();
		String hql="SELECT room FROM  RoomDetailsDTO room";
		Query query=entityManager.createQuery(hql);

		try {
			roomDetailsDTOs= query.getResultList();
			transaction.commit();
			return roomDetailsDTOs;
		}
		catch (Exception e) {
			e.printStackTrace();
			transaction.rollback();
		}
		entityManager.close();

		return roomDetailsDTOs;
	}

	public List<BookingDetailsDTO> listBookings() {
		List<BookingDetailsDTO> bookingDetailsDTOs=null;
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction();
		transaction.begin();
		String hql="SELECT booking FROM  BookingDetailsDTO booking";
		Query query=entityManager.createQuery(hql);

		try {
			bookingDetailsDTOs= query.getResultList();
			transaction.commit();
			return bookingDetailsDTOs;
		}
		catch (Exception e) {
			e.printStackTrace();
			transaction.rollback();
		}
		entityManager.close();


		return bookingDetailsDTOs;
	}



}
