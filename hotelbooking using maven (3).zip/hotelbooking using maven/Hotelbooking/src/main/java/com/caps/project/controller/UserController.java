package com.caps.project.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.caps.project.dto.UserDTO;
import com.caps.project.service.UserService;

@Controller
@RequestMapping("/user")
public class UserController {

	@Autowired
	private UserService userService;



	@RequestMapping(value = "/registerpage",method = RequestMethod.GET)public String registerPage()
	{
		return "Register";
	}

	@RequestMapping(value = "/loginpage",method = RequestMethod.GET)
	public String loginPage()
	{
		return "Login";
	}


	@RequestMapping(value = "/updatepage",method = RequestMethod.GET)
	public String updatePage()
	{
		return "Update";
	}
	
	@RequestMapping(value = "/userupdatepage",method = RequestMethod.GET)
	public String userUpdate()
	{
		return "UserUpdate";
	}
	
	@RequestMapping(value = "/deleteuserpage",method = RequestMethod.GET)
	public String deleteUser()
	{
		return "DeleteUser";
	}
	
	@RequestMapping(value = "/deleteadminpage",method = RequestMethod.GET)
	public String deleteAdmin()
	{
		return "DeleteAdmin";
	}
	
	@RequestMapping(value = "/listofusers",method = RequestMethod.GET)
	public String listUsers()
	{
	      
		return "UsersDisplay";
	}



	@RequestMapping(value="/registeruser",method=RequestMethod.POST)
	public ModelAndView  registerUser(@ModelAttribute UserDTO userDTO) {


		boolean result=userService.register(userDTO);

		if(result)
		{
			System.out.println(userDTO);
			return new ModelAndView("Login");

		}
		else
		{
			return new ModelAndView("Register");
		}

	}

	@RequestMapping(value="/loginuser",method=RequestMethod.POST)
	public ModelAndView  loginUser(@ModelAttribute UserDTO userDTO) {


		UserDTO user=userService.login(userDTO);

		if(user!=null)
		{
			if(user.getRole().equalsIgnoreCase("admin"))
			{
				System.out.println(user);
				return new ModelAndView("AdminHomePage");
			}else if(user.getRole().equalsIgnoreCase("employee"))
			{
				return new ModelAndView("UserHomepage");
			}else 
			{
				return new ModelAndView("UserHomepage");
			}

		}
		else
		{
			return new ModelAndView("Login");
		}

	}

	@RequestMapping(value="/updateuser",method=RequestMethod.POST)
	public ModelAndView adminUpdate(@ModelAttribute UserDTO userDTO)

	{

		boolean user=userService.update(userDTO);
		if(user)
		{
			if(userDTO.getRole().equals("admin"))
			{
				return new ModelAndView("AdminHomePage");
			}
			else
			{
				return new ModelAndView("Update");
			}
		}
		else
		{
			return new ModelAndView("Update");
		}

	}

	@RequestMapping(value="/userupdate",method=RequestMethod.POST)
	public ModelAndView userUpdate(UserDTO userDTO)

	{

		boolean user=userService.update(userDTO);
		if(user)
		{
			if(userDTO.getRole().equalsIgnoreCase("user"))
			{
				return new ModelAndView("UserHomepage");
			}
			else if(userDTO.getRole().equalsIgnoreCase("employee"))
			
			{
				return new ModelAndView("UserHomepage");
			}
			else
			{
				return new ModelAndView("Update");
			}
		}
		else
		{
			return new ModelAndView("Update");
		}

	}


	@RequestMapping(value="/deleteuser",method=RequestMethod.GET)
	public ModelAndView deleteUser(@RequestParam("userName") String name,@RequestParam("password") String password) {

		boolean result=userService.deleteUser(name,password);

		if(result)
		{

			return new ModelAndView("Register");
		}
		else
		{
			return new ModelAndView("DeleteAdmin");
		}

	}
	
	@RequestMapping(value="/userslist",method=RequestMethod.GET)
	public void listUser(HttpServletRequest request,HttpServletResponse response) throws IOException {

		List<UserDTO> users=userService.listUsers();
		PrintWriter out=response.getWriter();

		if(users!=null)
		{
			
			for (UserDTO userDTO : users) {
				if(userDTO.getRole().equals("employee"))
				{
					out.print("<h1> Employee Details are: </h1>");
					out.print("<h3> Employee name is:"+userDTO.getUserName()+"</h3>");
					out.print("<h3> Employee id is:</h3>"+userDTO.getUserId()+"</h3>");
					out.print("<h3> Employee Email is:</h3>"+userDTO.getEmail()+"</h3>");
					out.print("<h3> Employee Address is:</h3>"+userDTO.getAddress()+"</h3>");
					out.print("<h3> Employee MobileNo is:</h3>"+userDTO.getMobileNo()+"</h3>");
					out.print("<h3> Employee Phone is:</h3>"+userDTO.getPhone()+"</h3>");
					out.print("<h3> Employee Role is:</h3>"+userDTO.getRole()+"</h3>");
				}
				else if(userDTO.getRole().equals("user"))
				{
					out.println("<h1> Employee Details are: </h1>");
					out.print("<h3> Employee name is:</h3>"+userDTO.getUserName()+"</h3>");
					out.print("<h3> Employee id is:</h3>"+userDTO.getUserId()+"</h3>");
					out.print("<h3> Employee Email is:</h3>"+userDTO.getEmail()+"</h3>");
					out.print("<h3> Employee Address is:</h3>"+userDTO.getAddress()+"</h3>");
					out.print("<h3> Employee MobileNo is:</h3>"+userDTO.getMobileNo()+"</h3>");
					out.print("<h3> Employee Phone is:</h3>"+userDTO.getPhone()+"</h3>");
					out.print("<h3> Employee Role is:</h3>"+userDTO.getRole()+"</h3>");
				}
					
			}
		}
		else
		{
			out.println("<h3>No Users Found</h3>");
			
		}

	}


}
