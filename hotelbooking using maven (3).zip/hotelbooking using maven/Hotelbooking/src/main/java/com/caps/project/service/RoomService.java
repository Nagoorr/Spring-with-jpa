package com.caps.project.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.caps.project.dao.Dao;
import com.caps.project.dto.RoomDetailsDTO;

@Service
public class RoomService {

	@Autowired
	private Dao dao;

	public boolean addRoom(RoomDetailsDTO roomDetailsDTO) {
		
		boolean status=dao.addRoom(roomDetailsDTO);

		return status;
		
	}

	public boolean updateRoom(RoomDetailsDTO roomDetailsDTO) {

		boolean status=dao.updateRoom(roomDetailsDTO);

		return status;
	}

	public RoomDetailsDTO searchRoom(int primarykey) {

		RoomDetailsDTO detailsDTO=dao.searchRoom(primarykey);

		return detailsDTO;
	}

	public boolean deleteRoom(int primarykey) {
		
		boolean result=dao.deleteRoom(primarykey);

		return result;
	}

	
}
