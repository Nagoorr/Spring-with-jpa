package com.caps.project.dao;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.caps.project.dto.BookingDetailsDTO;
import com.caps.project.dto.HotelDTO;
import com.caps.project.dto.RoomDetailsDTO;
import com.caps.project.dto.UserDTO;

public interface Dao {

	boolean registerUser(UserDTO userDTO);
	boolean updateUser(UserDTO userDTO);
	boolean deleteUser(String name,String password);
	UserDTO userLogin(UserDTO userDTO);
	HotelDTO searchHotel(int id);
    boolean booking(BookingDetailsDTO bookingDetailsDTO);
    boolean addHotel(HotelDTO hotelDTO);
	boolean updateHotel(HotelDTO hotelDTO);
	boolean deleteHotel(int id);
	boolean addRoom(RoomDetailsDTO roomDetailsDTO);
    boolean updateRoom(RoomDetailsDTO roomDetailsDTO);
    RoomDetailsDTO searchRoom(int id);
    boolean deleteRoom(int id);
    List<UserDTO> listUsers();
    List<HotelDTO> listHotels();
    List<RoomDetailsDTO> listRooms();
    List<BookingDetailsDTO> listBookings();
	
   
}
