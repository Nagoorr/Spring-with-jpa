package com.caps.project.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.caps.project.dao.Dao;
import com.caps.project.dto.UserDTO;


@Service
public class UserService {
	
	@Autowired
	private Dao dao;
	
	public boolean register(UserDTO userDTO) {
		
		
	   boolean status=dao.registerUser(userDTO);
	    return status;
	}
	
	public UserDTO login(UserDTO userDTO) {
		
	    UserDTO status = dao.userLogin(userDTO);
	    return status;
	}
	
public boolean update(UserDTO userDTO) {
		
	    boolean status = dao.updateUser(userDTO);
	    return status;
	}

public boolean deleteUser(String name,String password) {
	
	       boolean status= dao.deleteUser(name,password);
	       return status;
	}

public List<UserDTO> listUsers() {
	
    List<UserDTO> usersList= dao.listUsers();
    return usersList;
}
}
