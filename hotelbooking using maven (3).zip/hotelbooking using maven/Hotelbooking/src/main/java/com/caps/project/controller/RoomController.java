package com.caps.project.controller;




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.caps.project.dto.RoomDetailsDTO;
import com.caps.project.service.RoomService;

@Controller
@RequestMapping("/user")
public class RoomController {
	
	@Autowired
	private RoomService roomService;
	
	 
	 
	@RequestMapping(value = "/addroompage",method = RequestMethod.GET)
	public String addRoom()
	{
		return "AddRoom";
	}
	
	@RequestMapping(value = "/updateroompage",method = RequestMethod.GET)
	public String updateRoom()
	{
		return "UpdateRoom";
	}
	
	@RequestMapping(value = "/searchroompage",method = RequestMethod.GET)
	public String searchRoom()
	{
		return "SearchRoom";
	}
	
	@RequestMapping(value = "/deleteroompage",method = RequestMethod.GET)
	public String deleteRoom()
	{
		return "DeleteRoom";
	}
	

	@RequestMapping("/addroom")
	public ModelAndView addRoom(@ModelAttribute RoomDetailsDTO roomDetailsDTO ) {
		
		
			boolean result=roomService.addRoom(roomDetailsDTO);

			if(result)
			{
				return new ModelAndView("AdminHomePage");
			}
			else
			{
				return new ModelAndView("RegisterHotel");
			}

		}

	
	@RequestMapping("/updateroom")
	public ModelAndView updateRoom(@ModelAttribute RoomDetailsDTO roomDetailsDTO) {
		
		boolean result=roomService.updateRoom(roomDetailsDTO);

		if(result)
		{
			return new ModelAndView("AdminHomePage");
		}
		else
		{
			return new ModelAndView("UpdateRoom");
		}

	}
	
	@RequestMapping("/searchroom")
   public ModelAndView searchRoom(@RequestParam("roomId") int primarykey) {
		
		RoomDetailsDTO roomDetailsDTO=roomService.searchRoom(primarykey);

		if(roomDetailsDTO!=null)
		{
			return new ModelAndView("RoomDetails","room",roomDetailsDTO);
		}
		else
		{
			return new ModelAndView("SearchRoom");
		}

	}

	@RequestMapping("/deleteroom")
     public ModelAndView deleteRoom(@RequestParam("roomId") int primarykey) {
	
	boolean result=roomService.deleteRoom(primarykey);

	if(result)
	{
		return new ModelAndView("AdminHomePage");
	}
	else
	{
		return new ModelAndView("DeleteRoom");
	}

}
	}

